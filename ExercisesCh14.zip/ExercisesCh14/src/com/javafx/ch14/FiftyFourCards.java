package com.javafx.ch14;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class FiftyFourCards extends Application {


	@Override
	public void start(Stage primaryStage) throws Exception {
		Pane hbox = new HBox();
		Image card;

		for (int i = 0; i <= 54 ; i++) {
			card = new Image("image/card/" + i + ".png");
			hbox.getChildren().add(new ImageView(card));
		}
		Scene scene = new Scene(hbox, 500, 300);
		primaryStage.setScene(scene);
		primaryStage.setTitle("14.8");
		primaryStage.show();
	}
	
	public static void main(String args) {
		launch(args);
	}
}
