package com.javafx.ch14;

public class Matrix {

	public Matrix() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
