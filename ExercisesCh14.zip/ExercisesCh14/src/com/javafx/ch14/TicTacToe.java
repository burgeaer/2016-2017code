package com.javafx.ch14;

import java.util.Random;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class TicTacToe extends Application {

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane gdpane = new GridPane();
		gdpane.setAlignment(Pos.CENTER);
		Image image = new Image("Java2/X.png");
	 
	    Image image2 = new Image("Java2/O.png");

	    Random rand = new Random();
	    int num;
	   for(int i = 0; i < 3; i++) {

		   for(int j = 0; j < 3; j++) {

			   num = rand.nextInt(3);
			   if (num != 0) {
				   if (num == 1) {
					   gdpane.add(new ImageView(image), i, j);
				   }

				   else {

					   gdpane.add(new ImageView(image2), i, j);
				   }
			   }
		   }
	   }

	   Scene scene = new Scene(gdpane, 500, 500);
	    primaryStage.setTitle("14.2");
	    primaryStage.setScene(scene);
	    primaryStage.show();



	}


}
