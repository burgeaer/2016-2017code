package com.javafx.ch14;


import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;



public abstract class Cards extends Application {
	static ArrayList<Integer> decklist = new ArrayList<>();
	static int[] threeNums = new int[3];

	public static void main(String[] args) {

		store52Numbers();
		Collections.shuffle(decklist);
		chooseThree(threeNums);
		displayNum(threeNums);

		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		Pane hbox = new HBox(5);
		Image card;

		for (int i = 0; i < threeNums.length; i++) {
			card = new Image("image/card/" + (threeNums[i]) + ".png");
			hbox.getChildren().add(new ImageView(card));
		}
		Scene scene = new Scene(hbox, 240, 100);
		primaryStage.setScene(scene);
		primaryStage.setTitle("14.3");
		primaryStage.show();
	}

	public static void displayNum(int[] threenums) {
		for (int i = 0; i < threeNums.length; i++) {

			System.out.print(threeNums[i] + " ");
		}

	}

	public static void chooseThree(int[] threenums) {
		Random rand = new Random();
		int num;
		int index = 0;
		for (int i = 52; i > 49; i--) {

			num = rand.nextInt(i);
			threeNums[index] = decklist.get(num);
			decklist.remove(num);
			index++;
		}
	}

	public static void store52Numbers() {
		for (int i = 1; i <= 52; i++) {
			decklist.add(i);
		}

	}



}




