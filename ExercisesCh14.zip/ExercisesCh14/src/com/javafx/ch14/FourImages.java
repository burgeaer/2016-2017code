package com.javafx.ch14;



import javafx.application.Application;

import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public  class FourImages extends Application {

	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
	GridPane gdpane = new GridPane();
	
    Image image = new Image("Java2/img1.png");
    ImageView img = new ImageView(image);
    img.setFitHeight(150);
    img.setFitWidth(200);
    Image image2 = new Image("Java2/img2.png");
    ImageView img2 = new ImageView(image2);
    img2.setFitHeight(150);
    img2.setFitWidth(200);
    Image image3 = new Image("Java2/img3.png");
    ImageView img3 = new ImageView(image3);
    img3.setFitHeight(150);
    img3.setFitWidth(200);
    Image image4 = new Image("Java2/img4.png");
	ImageView img4 = new ImageView(image4);
	img4.setFitHeight(150);
	img4.setFitWidth(200);
   
	gdpane.add(img, 2, 1);
	gdpane.add(img2, 1, 1);
	gdpane.add(img3, 1, 2);
	gdpane.add(img4, 2, 2);
	
    
	    Scene scene = new Scene(gdpane);
	    primaryStage.setTitle("14.1");
	    primaryStage.setScene(scene);
	    primaryStage.show();

}
	
	
	//int n = 5;
	//ImageView[] flags = new ImageView [5];
	
	//for(int i=0; i<n; i++) {
		//Image img = new Image("Java2/img" + i + ".png");
		//flags[i] = new ImageView(img);
	
	//Random rnd = new Random();
	//int r1 = rnd.nextInt(4);
	//int r2 = rnd.nextInt(4);
	
	
}

