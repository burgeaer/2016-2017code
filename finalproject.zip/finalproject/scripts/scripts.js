$(document).ready(function() {
    lightning_one(4000);
    lightning_two(5000);
    lightning_three(7000);

    $("img#game1").fadeIn(1000);
    $("img#game2").fadeIn(2000);
    $("img#game3").fadeIn(3000);
    $("img#game4").fadeIn(4000);
    $("img#game5").fadeIn(5000);

    $("img#creatorp").slideDown(1000);

    $("img.timeli").fadeIn(5000);
    $("td.time").fadeIn(7000);

    $("figure#imgs64").slideDown(1000);
    $("figure#imgsB").slideDown(1000);
    $("figure#imgsM").slideDown(1000);
    $("figure#imgsW").slideDown(1000);

    $("#refresh").click(function () {
        $('#link').load(document.URL + '#link');
    })
});

function lightning_one(t) {
    $("#lightning1").fadeIn(250).fadeOut(250);
    setTimeout("lightning_one()", t);
}

function lightning_two(t) {
    $("#lightning2").fadeIn(250).fadeOut(250);
    setTimeout("lightning_two()", t);
}

function lightning_three(t) {
    $("#lightning3").fadeIn(250).fadeOut(250);
    setTimeout("lightning_three()", t);
}
